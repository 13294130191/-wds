﻿#ifndef VIDEOS_H
#define VIDEOS_H

#include <QWidget>
#include <QProcess>

namespace Ui {
class Videos;
}

class Videos : public QWidget
{
    Q_OBJECT

public:
    explicit Videos(QWidget *parent = nullptr);
    ~Videos();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Videos *ui;
};

#endif // VIDEOS_H
