﻿#include "pic.h"
#include "ui_pic.h"
#include <QMessageBox>
#include "client.h"

pic::pic(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::pic)
{
    ui->setupUi(this);
}

pic::~pic()
{
    delete ui;
}

QByteArray PicData;


void pic:: picshow()
{
    QString URL = ui->PicPath->text();
    if(URL.left(5) == "https")
    {
        QMessageBox::critical(this, "error", "当前只http协议\n而输入的url为https协议");
    }
    PicData.clear();
    QUrl url(URL);
    QNetworkRequest request;
    request.setUrl(url);
    Picreply = Picmanager.get(request);

    connect(Picreply, &QNetworkReply::readyRead, this, &pic::read_pic);
    connect(Picreply, &QNetworkReply::finished, this, &pic::pic_progress);
}

void pic:: read_pic()
{
    QByteArray arr = Picreply->readAll();
    PicData.append(arr);
}

void pic:: pic_progress()
{
    Send();
    delete  this;
}



void pic::on_pushButton_clicked()
{
    if(ui->PicPath->text().length() < 5)
    {
        QMessageBox::warning(this, "warning", "地址格式错误");
        return ;
    }

    picshow();
}
