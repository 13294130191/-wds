﻿#ifndef INFO_H
#define INFO_H

#include <QWidget>
#include <QPainter>

namespace Ui {
class Info;
}

class Info : public QWidget
{
    Q_OBJECT

public:
    explicit Info(QWidget *parent = nullptr);
    ~Info();

    void  paintEvent(QPaintEvent* e);

    void timerEvent(QTimerEvent* e);


private:
    Ui::Info *ui;
};

extern QString fontcorlor;
extern int fontsize;
extern int fontspeed;
extern int mytimer;

#endif // INFO_H
