﻿#ifndef CLIENT_H
#define CLIENT_H

#include <QMainWindow>
#include <QMessageBox>
#include <QTcpSocket>
#include <QNetworkInterface>
#include <QThread>
#include <QProcess>
#include "videos.h"
#include "info.h"
#include "setinfo.h"

namespace Ui {
class Client;
}

class Client : public QMainWindow
{
    Q_OBJECT

public:
    explicit Client(QWidget *parent = nullptr);
    ~Client();

    void showpic();


private slots:
    void on_pushButton_clicked();

    void on_checkBox_toggled(bool checked);

    void on_checkBox_2_toggled(bool checked);

    void on_pushButton_5_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_ToServerBt_clicked();

    void client_read_data();

    void Recv();
    void on_pushButton_4_clicked();

    void dosetfinished();
private:
    Ui::Client *ui;
    QTcpSocket mysock;
    QString Information;
    QProcess mprocess;
};

extern QString today_wealther;
extern QString week_wealther;
extern QString today_environment;
extern int mytimer;
extern QByteArray PicData;
extern QString content;

#endif // CLIENT_H
