﻿#ifndef CITY_H
#define CITY_H

#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QByteArray>

namespace Ui {
class city;
}

class city : public QMainWindow
{
    Q_OBJECT

public:
    explicit city(QWidget *parent = nullptr);
    ~city();
    QString name;
    QByteArray WealtherData;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void read_reply();
    void weather_download();
private:
    Ui::city *ui;
    QNetworkAccessManager manager;
    QNetworkReply *reply;
};



#endif // CITY_H
