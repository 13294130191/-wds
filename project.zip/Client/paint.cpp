﻿#include "paint.h"
#include "client.h"
#include <QDebug>

int mytimer;

Paint::Paint(QWidget *parent) : QWidget(parent)
{

}

void Paint:: timedo(QMainWindow *ptr)
{
    qDebug()<< "计时器开始";
}

void Paint:: paintEvent(QPaintEvent* e)
{
    static int x = 0;
    //创建绘图对象
    QPainter painter(this->parentWidget());
    QFont font = painter.font();//获取当前的字体
    font.setPixelSize(24); //设置绘制文字大小
    font.setBold(true);//设置黑体
    painter.setFont(font);//设置绘制的字体
    //绘制文字
    painter.drawText(x,200, "时钟");
    x--; if(x < 0) x = this->width();
}

void Paint:: timerEvent(QTimerEvent* e)
{
    if(e->timerId() == mytimer)
     Paint::timedo((QMainWindow *)(this->parentWidget()));
}

void Paint:: timestart(QMainWindow *ptr)
{
     mytimer = ptr->startTimer(1000);
     qDebug()<< "开始";
}
