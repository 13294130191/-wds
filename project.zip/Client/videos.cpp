﻿#include "videos.h"
#include "ui_videos.h"
#include "client.h"

Videos::Videos(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Videos)
{
    ui->setupUi(this);
}

Videos::~Videos()
{
    delete ui;
}

extern QString MyPlayer;
extern QString MyVideo;

void Videos::on_pushButton_clicked()
{
    MyPlayer = ui->PlayerPath->text();
    MyVideo = ui->VidieoPath->text();
    if(MyPlayer.length() < 1 || MyVideo.length() < 1)
    {
        QMessageBox::warning(this, "warning", "输入格式有误");
        return ;
    }

    delete this;
}


