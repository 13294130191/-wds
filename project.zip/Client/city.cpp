﻿#include "city.h"
#include "ui_city.h"
#include <QMessageBox>
#include <QFile>
#include <QJsonParseError>
#include <QJsonObject>
#include <QJsonArray>
#include "client.h"

city::city(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::city)
{
    ui->setupUi(this);
}

city::~city()
{
    delete ui;
}

static QJsonDocument doc;

QString find_key(QWidget *ptr, QString cityname)
{
    QFile file("../citykeys.txt");
    if(!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::critical(ptr, "error", "open citykey.txt error!");
        return nullptr;
    }

    QString content = file.readAll();
    QStringList list = content.split(",");
    QString citykey;
    for(int i = 0; i < list.count(); i++)
    {
        if(list.at(i).startsWith("\"1") &&list.at(i).endsWith(cityname + "\""))
        {
            citykey = list.at(i).mid(1, 9);
            break;
        }

        if(i == list.count() - 1)
        {
            QMessageBox::critical(ptr, "error", "查不到该城市对应信息\n请检查城市名是否输入正确");
            return nullptr;
        }
    }

    file.close();
    return citykey;
}

void today_data()
{
    QJsonObject obj = doc.object();
    QJsonObject CityInfoObj = obj.value("cityInfo").toObject();
    QJsonObject DataObj = obj.value("data").toObject();
    QJsonArray dataObjArray = DataObj.value("forecast").toArray();
    QJsonObject  arrayObj = dataObjArray.at(0).toObject();


    QString city = "坐标: " + CityInfoObj.value("parent").toString() + " " + CityInfoObj.value("city").toString();
    QString time = "日期: " + obj.value("time").toString() + " " + arrayObj.value("week").toString();
    QString type = "今日天气: " + arrayObj.value("type").toString();
    QString quality = "空气质量： " + DataObj.value("quality").toString();
    QString wendu = "当前温度： " + DataObj.value("wendu").toString() + "℃";
    QString high = "今日最" + arrayObj.value("high").toString();
    QString low = "今日最" + arrayObj.value("low").toString();
    QString wind = "风向风速: " + arrayObj.value("fx").toString() + arrayObj.value("fl").toString();
    QString advice = "建议: " + DataObj.value("ganmao").toString();
    today_wealther = city + "\n" + time + "\n" + type +"\n" + quality + "\n" +
           wendu + "\n" + high + "\n" + low + "\n" + wind + "\n" + advice;
}

void week_data()
{
    QJsonObject obj = doc.object();
    QJsonObject CityInfoObj = obj.value("cityInfo").toObject();
    QJsonObject DataObj = obj.value("data").toObject();
    QJsonArray dataObjArray = DataObj.value("forecast").toArray();

    QString data = "";
    QString city = "坐标: " + CityInfoObj.value("parent").toString() + " " + CityInfoObj.value("city").toString();
    QString time, type, high, low, wind, notice = "";
    for(int i = 1; i < 8; i++)
    {
        QJsonObject DayObj =  dataObjArray.at(i).toObject();

        QString time = "日期: " + DayObj.value("ymd").toString() + " " + DayObj.value(" week").toString();
        QString type = "今日天气: " + DayObj.value("type").toString();
        QString high = "今日最" + DayObj.value("high").toString();
        QString low = "今日最" + DayObj.value("low").toString();
        QString wind = "风向风速: " + DayObj.value("fx").toString() + DayObj.value("fl").toString();
        QString notice = "建议: " + DayObj.value("notice").toString();
        data = data.append( city + "\n" + time + "\n" + type +"\n" +
                                    high + "\n" + low + "\n" + wind + "\n" + notice + "\n\n");
    }

    week_wealther = data;
}

void today_envir()
{
    QJsonObject obj = doc.object();
    QJsonObject DataObj = obj.value("data").toObject();


    int pm25 = DataObj.value("pm25").toInt();
    int pm10 = DataObj.value("pm10").toInt();
    QString s25 = "PM2.5指数：" + QString::number(pm25);
    QString s10 = "PM1.0指数：" + QString::number(pm10);
    QString shidu = "空气湿度：" + DataObj.value("shidu").toString();

    today_environment = s25 + "\n" + s10 + "\n" + shidu;
}

void city::on_pushButton_clicked()
{
    if(ui->lineEdit->text().length() == 0)
    {
        QMessageBox::warning(this, "warning", "城市名不能为空");
        return ;
    }

    name = ui->lineEdit->text();
    find_key(this, name);
    qDebug() << find_key(this, name);
    QString key =  find_key(this, name);
    QString urlstr = QString("http://t.weather.sojson.com/api/weather/city/%1").arg(key);                                                      /************************/
    QUrl url(urlstr);
                                                                                                                                               /* Code of WealtherFind */
    QNetworkRequest request;
    request.setUrl(url);                                                                                                                       /************************/
    reply = manager.get(request);

    connect(reply, &QNetworkReply::readyRead, this, &city::read_reply);
    connect(reply, &QNetworkReply::finished, this, &city::weather_download);
}

void city:: read_reply()
{
    QByteArray array = reply->readAll();
    WealtherData.append(array);
}

void city:: weather_download()
{
    QJsonParseError error;
    doc = QJsonDocument::fromJson(WealtherData, &error);
    if(error.error != QJsonParseError::NoError)
    {
        QMessageBox::critical(this, "error", "解析数据失败！");
        qDebug() << error.error;
        return ;
    }

    today_data();
    week_data();
    today_envir();

    this->parentWidget()->show();
    delete this;
}

void city::on_pushButton_2_clicked()
{
    this->parentWidget()->show();
    delete this;
}

