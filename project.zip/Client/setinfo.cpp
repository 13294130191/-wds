﻿#include "setinfo.h"
#include "ui_setinfo.h"
#include "info.h"

extern int mytimer;
SetInfo::SetInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SetInfo)
{
    ui->setupUi(this);
    ui->lineEdit->setText(QString::number(fontsize));
    ui->lineEdit_2->setText(QString::number(fontspeed));
    ui->lineEdit_3->setText(fontcorlor);
}

SetInfo::~SetInfo()
{
    delete ui;
}

void SetInfo::on_pushButton_clicked()
{
    fontsize   = ui->lineEdit->text().toInt();
    fontspeed  = ui->lineEdit_2->text().toInt();
    fontcorlor = ui->lineEdit_3->text();
    if(mytimer)
    {
        killTimer(mytimer);
    }
    setsend();
    delete this;
}
