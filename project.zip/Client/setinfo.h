﻿#ifndef SETINFO_H
#define SETINFO_H

#include <QWidget>

namespace Ui {
class SetInfo;
}

class SetInfo : public QWidget
{
    Q_OBJECT

public:
    explicit SetInfo(QWidget *parent = nullptr);
    ~SetInfo();

    void setsend()
    {
        emit setfinied();
    }

signals:
    void setfinied();

private slots:
    void on_pushButton_clicked();

private:
    Ui::SetInfo *ui;
};


#endif // SETINFO_H
