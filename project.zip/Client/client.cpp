﻿#include "client.h"
#include "ui_client.h"
#include "city.h"
#include "pic.h"
#include <unistd.h>

Client::Client(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Client)
{
    ui->setupUi(this);
    connect(&mysock, &QTcpSocket::readyRead, this, &Client::client_read_data);
}

Client::~Client()
{
    delete ui;
}

Info *p = nullptr;
QString today_wealther;
QString week_wealther;
QString today_environment;
static int connect_flag = 0;
extern QByteArray PicData;
QString MyPlayer;
QString MyVideo;

void Client::on_pushButton_clicked()
{
    city *cityname = new city(this);
    cityname->show();
    this->hide();
}

void Client::on_checkBox_toggled(bool checked)
{
    if(checked == true)
    {
        ui->label->clear();
        ui->label->setText(today_wealther);
    }else{
        ui->label->clear();
    }

}

void Client::on_checkBox_2_toggled(bool checked)
{
    if(checked == true)
    {
        ui->label->clear();
        ui->label->setText(week_wealther);
    }else{
        ui->label->clear();
    }
}

void Client::on_pushButton_5_clicked()
{
    SetInfo *s = new SetInfo();
    s->show();
    connect(s, &SetInfo::setfinied, this, &Client::dosetfinished);
}

void Client:: dosetfinished()
{
    Info *in = new Info(ui->InfoText);
    in->show();
    if(p == nullptr)
    {
        p = in;
        return ;
    }

    delete p;
    p = in;
}

void Client::on_pushButton_2_clicked()
{
    if(today_environment.length() < 1 )
    {
        QMessageBox::warning(this, "warning", "请先获取天气信息");
        return ;
    }

    ui->label->clear();
    ui->label->setText(today_environment);
}

void Client::on_pushButton_3_clicked()
{
    pic *p = new pic();
    p->show();

    connect(p, &pic::DownLoadFiniehed, this, &Client::Recv);
}

void Client:: Recv()
{
    QPixmap map;
    map.loadFromData(PicData);
    map = map.scaled(ui->label->size());
    ui->label->setPixmap(map);
    PicData.clear();
}

void Client::on_ToServerBt_clicked()
{
    QString ip = ui->IpLine->text();
    QString port = ui->PortLine->text();
    if(ip.length() == 0 || port.length() == 0)
    {
        QMessageBox::critical(this, "error", "输入不能为空！");
        return ;
    }

    connect_flag = 1;
    mysock.connectToHost(ip, port.toUShort());
}

void Client::client_read_data()
{
    QTcpSocket *mysocket = qobject_cast<QTcpSocket *>(sender());
    QString data = mysocket->readAll();

    content = data;
}

void Client::on_pushButton_4_clicked()
{
    Videos *v = new Videos();
    v->show();
    if(mprocess.state() == QProcess::Running)
    {
        mprocess.kill();
        mprocess.waitForFinished();
    }
    QStringList args;
    args<<"-quiet"<<"-slave"<<"-wid"<<QString::number(ui->label->winId());
    args<<MyVideo;

    mprocess.start(MyPlayer, args);
}
