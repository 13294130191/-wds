﻿#ifndef PAINT_H
#define PAINT_H

#include <QWidget>
#include <QPainter>
#include <QTimerEvent>
#include <QPaintEvent>
#include <QMainWindow>

class Paint : public QWidget
{
    Q_OBJECT
public:
    explicit Paint(QWidget *parent = nullptr);

    void paintEvent(QPaintEvent* e);
    void timerEvent(QTimerEvent* e);
    void timedo(QMainWindow *ptr);
    void timestart(QMainWindow *ptr);

signals:

public slots:
};

#endif // PAINT_H
