﻿#ifndef PIC_H
#define PIC_H

#include <QWidget>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include "client.h"

#include <QCoreApplication>

namespace Ui {
class pic;
}

class pic : public QWidget
{
    Q_OBJECT

public:
    explicit pic(QWidget *parent = nullptr);
    ~pic();
    void picshow();

    void Send()
    {
        emit DownLoadFiniehed();
    }

signals:
    void DownLoadFiniehed();

private slots:
    void read_pic();
    void pic_progress();
    void on_pushButton_clicked();

private:
    Ui::pic *ui;
    QNetworkAccessManager Picmanager;
    QNetworkReply *Picreply;
};


#endif // PIC_H
