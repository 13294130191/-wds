﻿#include "info.h"
#include "ui_info.h"
#include "setinfo.h"
#include "client.h"
#include <QStringList>

QString fontcorlor = "255,0,0";
int fontsize = 34;
int fontspeed = 20;
int mytimer = 0;

QString content;

Info::Info(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Info)
{
    ui->setupUi(this);
    mytimer =this->startTimer(fontspeed);
}

Info::~Info()
{
    delete ui;
}

void Info::paintEvent(QPaintEvent *e)
{
    static int x = 0;
    QPainter painter(this);

    QPen pen = painter.pen();
    QStringList list = fontcorlor.split(",");
    int r = list.at(0).toInt();
    int g = list.at(1).toInt();
    int b = list.at(2).toInt();
    QColor c(r,g,b);
    pen.setColor(c);
    painter.setPen(pen);
    QFont font = painter.font();
    font.setPixelSize(fontsize);
    //font.setBold(true);
    painter.setFont(font);
    painter.drawText(x,60, content);
    x--; if(x < 0) x = this->width();
}

void Info::timerEvent(QTimerEvent *e)
{
    if(e->timerId() == mytimer)
         this->update();
}


