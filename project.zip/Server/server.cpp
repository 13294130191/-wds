﻿#include "server.h"
#include "ui_server.h"

Server::Server(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Server)
{
    ui->setupUi(this);
    connect(&myserver, &QTcpServer::newConnection, this, &Server::new_client);
}

Server::~Server()
{
    delete ui;
}

static int listen_flag = 0;

void Server::on_ListenBt_clicked()
{
    if(listen_flag == 1)
    {
        quint16 port = ui->PortLine->text().toUShort();
        QMessageBox::critical(this, "error",QString("监听端口号[%1]失败！\n该端口已被监听").arg(port));
        return ;
    }

    if(ui->PortLine->text().length())
    {
        quint16 port = ui->PortLine->text().toUShort();
        if(!myserver.listen(QHostAddress::AnyIPv4, port))
        {
            QMessageBox::critical(this, "error",QString("监听端口号[%1]失败!").arg(port));
            return ;
        }
    }

    else{
        QMessageBox::critical(this, "error", "端口号不能为空");
        return ;
    }

    listen_flag = 1;
}

void Server:: new_client()//当有新的客户端连接到服务器时
{
    QTcpSocket *mysocket = myserver.nextPendingConnection();
    QString currentip = mysocket->peerAddress().toString();
    ui->Connected->addItem(currentip);

    myvector.append(mysocket);
}

void Server:: client_deadline()//当当前有客户端失去连接时
{
    QTcpSocket *mysocket = qobject_cast<QTcpSocket *>(sender());

    int row = myvector.indexOf(mysocket);
    myvector.removeAt(row);

    QListWidgetItem *item = ui->Connected->takeItem(row);
    delete item;
}

void Server::on_QuitBt_clicked()
{
    if(listen_flag)
    {
        QMessageBox::information(this, "waiting···", "监听关闭！");
        myserver.close();
        listen_flag = 0;
    }
        else{
        QMessageBox::warning(this, "waring", "当前该服务器没有监听任何端口");
    }
}

void Server::on_SetInfo_clicked()
{
    int row = ui->Connected->currentRow();
    if(row < 0)
    {
        QMessageBox::critical(this, "error", "发送消息失败：\n当前没有选中任何目标地址");
        return ;
    }

    QString msg = ui->InfoText->toPlainText();
    QTcpSocket *mysocket = myvector.at(row);

    mysocket->write(msg.toUtf8());
}

void Server::on_ClearBt_clicked()
{
    ui->InfoText->clear();
}
