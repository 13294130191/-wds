﻿#ifndef SERVER_H
#define SERVER_H

#include <QMainWindow>
#include <QTcpServer>
#include <QMessageBox>
#include <QTcpSocket>

namespace Ui {
class Server;
}

class Server : public QMainWindow
{
    Q_OBJECT

public:
    explicit Server(QWidget *parent = nullptr);
    ~Server();

private slots:
    void on_ListenBt_clicked();

    void on_QuitBt_clicked();

    void new_client();
    void read_data();
    void client_deadline();
    void on_SetInfo_clicked();

    void on_ClearBt_clicked();

private:
    Ui::Server *ui;
    QTcpServer myserver;
    QVector<QTcpSocket *> myvector;

};

#endif // SERVER_H
